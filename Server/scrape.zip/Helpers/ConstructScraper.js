"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const LeagueParser_1 = __importDefault(require("../Parsers/LeagueParser"));
const RuneterraParser_1 = __importDefault(require("../Parsers/RuneterraParser"));
const ApexParser_1 = __importDefault(require("../Parsers/ApexParser"));
const FortniteParser_1 = __importDefault(require("../Parsers/FortniteParser"));
const ValorantParser_1 = __importDefault(require("../Parsers/ValorantParser"));
const OverwatchParser_1 = require("../Parsers/OverwatchParser");
const CounterStrikeParser_1 = __importDefault(require("../Parsers/CounterStrikeParser"));
const HearthstoneParser_1 = __importDefault(require("../Parsers/HearthstoneParser"));
const TFTParser_1 = __importDefault(require("../Parsers/TFTParser"));
const GenericScraper_1 = __importDefault(require("../Scrapers/GenericScraper"));
const OverwatchDetailsScraper_1 = __importDefault(require("../Scrapers/OverwatchDetailsScraper"));
function constructScraper(request) {
    let scraper;
    switch (request.gameID) {
        case 1:
            scraper = new GenericScraper_1.default("https://www.ea.com/en-gb/games/apex-legends/news#news", ApexParser_1.default, false);
            break;
        case 2:
            const url = getCounterStrikeScrapeParameters(request.type);
            scraper = new GenericScraper_1.default(url, CounterStrikeParser_1.default);
            break;
        case 3:
            scraper = new GenericScraper_1.default("https://www.epicgames.com/fortnite/en-US/news", FortniteParser_1.default);
            break;
        case 4:
            scraper = new GenericScraper_1.default("https://playhearthstone.com/en-us/news", HearthstoneParser_1.default);
            break;
        case 5:
            scraper = new GenericScraper_1.default("https://na.leagueoflegends.com/en-us/latest-news/", LeagueParser_1.default);
            break;
        case 6:
            scraper = getOverwatchScraper(request);
            break;
        case 7:
            scraper = new GenericScraper_1.default("https://playruneterra.com/en-us/news", RuneterraParser_1.default);
            break;
        case 8:
            scraper = new GenericScraper_1.default("https://playvalorant.com/en-us/news/", ValorantParser_1.default);
            break;
        case 9:
            scraper = new GenericScraper_1.default("https://teamfighttactics.leagueoflegends.com/en-us/news/", TFTParser_1.default);
            break;
        default:
            return null;
    }
    return scraper;
}
exports.default = constructScraper;
function getCounterStrikeScrapeParameters(type) {
    let url;
    if (!type || type === "news")
        url = "https://blog.counter-strike.net/";
    else
        url = "https://blog.counter-strike.net/index.php/category/updates/";
    return url;
}
function getOverwatchScraper(request) {
    let url;
    let parser;
    let scraper;
    if (!request.type || request.type === "news") {
        url = "https://playoverwatch.com/en-us/news";
        parser = OverwatchParser_1.OverwatchNewsParser;
        scraper = new GenericScraper_1.default(url, parser);
    }
    else if (request.type === "patch") {
        url = "https://playoverwatch.com/en-us/news/patch-notes/live";
        parser = OverwatchParser_1.OverwatchPatchParser;
        scraper = new GenericScraper_1.default(url, parser);
    }
    else {
        url = request.article.link;
        parser = OverwatchParser_1.OverwatchArticleDateParser;
        scraper = new OverwatchDetailsScraper_1.default(url, parser, request.article);
    }
    return scraper;
}
//# sourceMappingURL=ConstructScraper.js.map