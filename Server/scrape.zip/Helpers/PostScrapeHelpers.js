"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const moment_1 = __importDefault(require("moment"));
const aws_sdk_1 = __importDefault(require("aws-sdk"));
// Query the most recent 30 articles to use as reference to see if they exist.
function getArticlesByGameId(gameID, db, callback) {
    console.log("Querying DB");
    db.query("SELECT * FROM articles WHERE game_id = ? ORDER BY id limit 30", gameID, (err, result) => {
        if (err) {
            callback(null);
        }
        else {
            callback(result);
        }
    });
}
exports.getArticlesByGameId = getArticlesByGameId;
// O(n^2) but only a max N of 30 so I'm going to say its OK.
function checkForNewArticles(input, existing) {
    const ret = [];
    input.forEach((inputObj) => {
        const exists = existing.some((e) => e.title === inputObj.title);
        if (!exists)
            ret.push(inputObj);
    });
    return ret;
}
exports.checkForNewArticles = checkForNewArticles;
function insertArticlesToDatabase(newArticles, gameID, db) {
    const formattedInserts = formatArticlesToInsertStatements(newArticles, gameID);
    const queryString = "INSERT INTO articles (title, description, link, imageUrl, category, game_id, date_published, date_entered) VALUES ?";
    db.query(queryString, [formattedInserts], (err, result) => {
        if (err) {
            throw err;
        }
    });
}
exports.insertArticlesToDatabase = insertArticlesToDatabase;
function formatArticlesToInsertStatements(newArticles, gameID) {
    let results = [];
    for (let i = 0; i < newArticles.length; i++) {
        let currentResult = [];
        const article = newArticles[i];
        currentResult.push(article.title);
        currentResult.push(article.description);
        currentResult.push(article.link);
        currentResult.push(article.imageUrl);
        currentResult.push(article.category);
        currentResult.push(gameID);
        currentResult.push(formatDate(article.rawDatetime));
        currentResult.push(moment_1.default(Date.now()).format("YYYY-MM-DD HH:mm:ss"));
        results.push(currentResult);
    }
    return results;
}
exports.formatArticlesToInsertStatements = formatArticlesToInsertStatements;
// Takes a date string and formats into YYYY-MM-DD
function formatDate(dateString) {
    const d = new Date(dateString);
    const isValidDate = d instanceof Date && !isNaN(d);
    if (!isValidDate)
        return null;
    let month = "" + (d.getMonth() + 1);
    let day = "" + d.getDate();
    const year = d.getFullYear();
    if (month.length < 2)
        month = "0" + month;
    if (day.length < 2)
        day = "0" + day;
    return [year, month, day].join("-");
}
exports.formatDate = formatDate;
function isOverwatchNews(requestMessage) {
    return requestMessage.gameID === 6 && (!requestMessage.type || requestMessage.type === "news");
}
exports.isOverwatchNews = isOverwatchNews;
function produceOverwatchDetailsMessagesToSQS(newArticles) {
    const sqs = new aws_sdk_1.default.SQS();
    newArticles.forEach((article) => {
        const newMessage = {
            gameID: 6,
            type: "details",
            article: article,
        };
        const messageString = JSON.stringify(newMessage);
        const params = {
            MessageBody: messageString,
            DelaySeconds: 0,
            QueueUrl: "https://sqs.us-west-2.amazonaws.com/655373160788/articles",
        };
        sqs.sendMessage(params, function (err, _) {
            if (err)
                console.log(err);
        });
    });
    return;
}
exports.produceOverwatchDetailsMessagesToSQS = produceOverwatchDetailsMessagesToSQS;
function sendArticlesToWebsocketServer(newArticles) {
    const sqs = new aws_sdk_1.default.SQS();
    newArticles.forEach((article) => {
        const message = JSON.stringify(article);
        const params = {
            MessageBody: message,
            DelaySeconds: 0,
            QueueUrl: "https://sqs.us-west-2.amazonaws.com/655373160788/toWebsocketServer",
        };
        sqs.sendMessage(params, function (err, _) {
            if (err)
                console.log(err);
        });
    });
    return;
}
exports.sendArticlesToWebsocketServer = sendArticlesToWebsocketServer;
//# sourceMappingURL=PostScrapeHelpers.js.map