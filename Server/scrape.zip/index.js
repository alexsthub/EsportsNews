"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const dbConnect_1 = __importDefault(require("./db/dbConnect"));
const ConstructScraper_1 = __importDefault(require("./Helpers/ConstructScraper"));
const PostScrapeHelpers_1 = require("./Helpers/PostScrapeHelpers");
const aws_sdk_1 = __importDefault(require("aws-sdk"));
aws_sdk_1.default.config.update({ region: "us-west-2" });
// (async function () {
//   const requestMessage: Request = {
//     gameID: 5,
//     type: "news",
//   };
//   const scraper: Scraper = constructScraper(requestMessage);
//   const scrapedArticles: Data[] = await scraper.scrape();
//   console.log(scrapedArticles);
//   getArticlesByGameId(requestMessage.gameID, db, (result: any) => {
//     if (!result) return;
//     const newArticles: Data[] = checkForNewArticles(scrapedArticles, result);
//     if (newArticles.length > 0) {
//       if (isOverwatchNews(requestMessage)) {
//         return produceOverwatchDetailsMessagesToSQS(newArticles);
//       } else {
//         insertArticlesToDatabase(newArticles, requestMessage.gameID, db);
//         return sendArticlesToWebsocketServer(newArticles);
//       }
//     }
//   });
// })();
exports.handler = async (event) => {
    const record = event.Records[0];
    const body = record.body;
    const requestMessage = JSON.parse(body);
    const scraper = ConstructScraper_1.default(requestMessage);
    const scrapedArticles = await scraper.scrape();
    if (!scrapedArticles || scrapedArticles.length === 0)
        return;
    console.log(scrapedArticles);
    PostScrapeHelpers_1.getArticlesByGameId(requestMessage.gameID, dbConnect_1.default, (result) => {
        console.log("RESULT");
        console.log(result);
        if (!result)
            return;
        const newArticles = PostScrapeHelpers_1.checkForNewArticles(scrapedArticles, result);
        console.log("NEW ARTICLES");
        console.log(newArticles);
        if (newArticles.length > 0) {
            if (PostScrapeHelpers_1.isOverwatchNews(requestMessage)) {
                return PostScrapeHelpers_1.produceOverwatchDetailsMessagesToSQS(newArticles);
            }
            else {
                console.log("Inserting");
                PostScrapeHelpers_1.insertArticlesToDatabase(newArticles, requestMessage.gameID, dbConnect_1.default);
                return PostScrapeHelpers_1.sendArticlesToWebsocketServer(newArticles);
            }
        }
    });
    return;
};
//# sourceMappingURL=index.js.map