"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function FortniteParser() {
    let documents = [];
    const grid = document
        .querySelector("div.row")
        .getElementsByTagName("a");
    for (let i = 0; i < grid.length; i++) {
        const card = grid[i];
        const gridContent = card.querySelector(".grid-content");
        const link = card.href;
        const imageUrl = card.querySelector("img").src;
        const rawDatetime = gridContent.querySelector(".date").innerHTML;
        const title = gridContent.querySelector(".title").innerHTML;
        const doc = {
            title: title,
            link: link,
            imageUrl: imageUrl,
            rawDatetime: rawDatetime,
        };
        documents.push(doc);
    }
    return documents;
}
exports.default = FortniteParser;
//# sourceMappingURL=FortniteParser.js.map