"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function LeagueParser() {
    function getCategory(title) {
        const lowerTitle = title.toLowerCase();
        if (lowerTitle.includes("patch") && lowerTitle.includes("note")) {
            return "update";
        }
        return "general";
    }
    let documents = [];
    const grid = document.querySelector("ol");
    const articles = grid.querySelectorAll("li");
    for (let i = 0; i < articles.length; i++) {
        const article = articles[i];
        const titleElement = article.querySelector("h2");
        if (titleElement === null ||
            titleElement.innerHTML.includes("Teamfight Tactics") ||
            titleElement.innerHTML.includes("TFT")) {
            continue;
        }
        const title = titleElement.innerHTML;
        const textContainer = article.querySelector("h2").parentElement;
        const link = article.querySelector("a").href;
        const imageUrl = article.querySelector("img").src;
        const rawDatetime = textContainer.querySelector("time").dateTime;
        const category = getCategory(title);
        const document = {
            title: title,
            link: link,
            rawDatetime: rawDatetime,
            imageUrl: imageUrl,
            category: category,
        };
        documents.push(document);
    }
    return documents;
}
exports.default = LeagueParser;
//# sourceMappingURL=LeagueParser.js.map