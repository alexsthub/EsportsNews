"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function HearthstoneParser() {
    function getCategory(title) {
        const lowerTitle = title.toLowerCase();
        if (lowerTitle.includes("patch notes") || lowerTitle.includes("updates")) {
            return "update";
        }
        return "general";
    }
    let documents = [];
    const parent = document.querySelector("div.ContentSection");
    const grid = parent.querySelector("div[class^=NewsHomeApp__NewsListContainer]");
    const articles = grid.children;
    for (let i = 0; i < articles.length; i++) {
        const article = articles[i];
        const link = article.href;
        const imageUrl = article.querySelector("img").src;
        const title = article.querySelector("h3").innerHTML;
        const description = article.querySelector("p").innerHTML.trim();
        const rawDatetime = article.querySelector("time").innerHTML;
        const category = getCategory(title);
        const doc = {
            title: title,
            link: link,
            imageUrl: imageUrl,
            description: description,
            rawDatetime: rawDatetime,
            category: category,
        };
        documents.push(doc);
    }
    return documents;
}
exports.default = HearthstoneParser;
//# sourceMappingURL=HearthstoneParser.js.map