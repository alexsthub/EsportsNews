"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function TFTParser() {
    function getCategory(title) {
        const lowerTitle = title.toLowerCase();
        if (lowerTitle.includes("patch") && lowerTitle.includes("notes")) {
            return "update";
        }
        return "general";
    }
    let documents = [];
    const grid = document.querySelectorAll("ol")[1];
    const articles = grid.querySelectorAll("li");
    for (let i = 0; i < articles.length; i++) {
        const article = articles[i];
        const textContainer = article.querySelector("h2").parentElement;
        const title = article.querySelector("h2").innerHTML;
        const link = article.querySelector("a").href;
        const imageUrl = article.querySelector("img").src;
        const description = textContainer.querySelector("p").innerHTML;
        const rawDatetime = textContainer.querySelector("time").dateTime;
        const category = getCategory(title);
        const doc = {
            title: title,
            description: description,
            link: link,
            imageUrl: imageUrl,
            rawDatetime: rawDatetime,
            category: category,
        };
        documents.push(doc);
    }
    return documents;
}
exports.default = TFTParser;
//# sourceMappingURL=TFTParser.js.map