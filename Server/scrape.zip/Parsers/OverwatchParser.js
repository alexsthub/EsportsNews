"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function OverwatchArticleDateParser() {
    const dateElement = document.querySelector("span.publish-date");
    if (dateElement) {
        const rawDatetime = dateElement.innerHTML;
        return rawDatetime;
    }
    return null;
}
exports.OverwatchArticleDateParser = OverwatchArticleDateParser;
function OverwatchNewsParser() {
    function getImageUrl(article) {
        const imageDiv = article.querySelector(".Card-thumbnail");
        const rawUrl = imageDiv.style.backgroundImage;
        return rawUrl.substr(7, rawUrl.length - 9);
    }
    let documents = [];
    const featuredDiv = document.querySelector("section.NewsHeader-featured");
    const featuredArticles = featuredDiv.querySelectorAll("a.CardLink");
    for (let i = 0; i < featuredArticles.length; i++) {
        const article = featuredArticles[i];
        const imageUrl = getImageUrl(article);
        const link = article.href;
        const title = article.querySelector("h1.Card-title").innerHTML;
        const category = "general";
        const doc = {
            title: title,
            link: link,
            imageUrl: imageUrl,
            category: category,
        };
        documents.push(doc);
    }
    return documents;
}
exports.OverwatchNewsParser = OverwatchNewsParser;
function OverwatchPatchParser() {
    function getLink() {
        const currentDate = new Date();
        const baseUrl = "https://playoverwatch.com/en-us/news/patch-notes/live/"; // year/month
        const year = currentDate.getFullYear();
        const month = currentDate.getMonth() + 1;
        const link = baseUrl + year + "/" + month;
        return link;
    }
    let documents = [];
    const body = document.querySelector("div.PatchNotes-body");
    const articles = body.querySelectorAll("div.PatchNotes-patch");
    const link = getLink();
    for (let i = 0; i < articles.length; i++) {
        const article = articles[i];
        const title = article.querySelector("h3").innerHTML;
        const rawDatetime = article.querySelector("div.PatchNotes-date").innerHTML;
        const category = "update";
        const doc = {
            rawDatetime: rawDatetime,
            title: title,
            category: category,
            link: link,
        };
        documents.push(doc);
    }
    return documents;
}
exports.OverwatchPatchParser = OverwatchPatchParser;
//# sourceMappingURL=OverwatchParser.js.map