"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function ValorantParser() {
    function getImageUrl(body) {
        const imageDiv = body.querySelector("div[class*=imageWrapper]");
        const imageUrl = imageDiv.querySelector("span").style.backgroundImage;
        return imageUrl.substr(5, imageUrl.length - 7);
    }
    function getCategory(title) {
        const lowerTitle = title.toLowerCase();
        if (lowerTitle.includes("patch") && lowerTitle.includes("notes")) {
            return "update";
        }
        return "general";
    }
    let documents = [];
    const grid = document.querySelector("[class^=NewsArchive-module--content]");
    const articles = grid.children;
    for (let i = 0; i < articles.length; i++) {
        const article = articles[i];
        const body = article.querySelector("a");
        const textContent = body.querySelector("div[class^=NewsCard-module--copyContainer]");
        const link = body.href;
        const rawDatetime = textContent.children[0].innerHTML;
        const title = textContent.children[1].innerHTML;
        const description = textContent.children[2].innerHTML;
        const imageUrl = getImageUrl(body);
        const category = getCategory(title);
        const doc = {
            link: link,
            rawDatetime: rawDatetime,
            title: title,
            description: description,
            imageUrl: imageUrl,
            category: category,
        };
        documents.push(doc);
    }
    return documents;
}
exports.default = ValorantParser;
//# sourceMappingURL=ValorantParser.js.map