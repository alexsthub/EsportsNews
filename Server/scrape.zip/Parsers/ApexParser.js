"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function ApexParser() {
    function getLinkUrl(card) {
        const anchorParent = card.querySelector("ea-cta");
        const anchor = anchorParent ? anchorParent.querySelector("a") : null;
        return anchor ? anchor.href : null;
    }
    function getCategory(title) {
        const lowerTitle = title.toLowerCase();
        if (lowerTitle.includes("patch notes") || lowerTitle.includes("update")) {
            return "update";
        }
        return "general";
    }
    let documents = [];
    const grid = document
        .querySelector("body > iron-pages > div.iron-selected > ea-section > ea-section-column > ea-grid")
        .shadowRoot.querySelector("#catalogContainer");
    const cards = grid.getElementsByTagName("ea-tile");
    for (let i = 0; i < cards.length; i++) {
        const card = cards[i];
        const title = card.getAttribute("title-text");
        const imageUrl = card.getAttribute("media");
        const link = getLinkUrl(card);
        const description = card.querySelector("ea-tile-copy").innerHTML.trim();
        const rawDatetime = card.getAttribute("eyebrow-secondary-text");
        const category = getCategory(title);
        const doc = {
            title: title,
            imageUrl: imageUrl,
            link: link,
            description: description,
            rawDatetime: rawDatetime,
            category: category,
        };
        documents.push(doc);
    }
    return documents;
}
exports.default = ApexParser;
//# sourceMappingURL=ApexParser.js.map