"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
function CounterStrikeParser() {
    function getCategory(title) {
        const lowerTitle = title.toLowerCase();
        if (lowerTitle.includes("release") && lowerTitle.includes("note")) {
            return "update";
        }
        return "general";
    }
    let documents = [];
    const grid = document.querySelector("div#post_container");
    const articles = grid.querySelectorAll("div.inner_post");
    for (let i = 0; i < articles.length; i++) {
        const article = articles[i];
        const anchor = article.querySelector("h2").querySelector("a");
        const dateDiv = article.querySelector("p.post_date");
        const link = anchor.href;
        const title = anchor.innerHTML;
        const rawDatetime = dateDiv.innerText.replace("-", "").trim();
        const category = getCategory(title);
        const doc = {
            title: title,
            link: link,
            rawDatetime: rawDatetime,
            category: category,
        };
        documents.push(doc);
    }
    return documents;
}
exports.default = CounterStrikeParser;
//# sourceMappingURL=CounterStrikeParser.js.map