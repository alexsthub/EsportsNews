"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const mysql_1 = __importDefault(require("mysql"));
const port = 3306;
let con = mysql_1.default.createConnection({
    host: "news.c2cq8ee6kdum.us-west-2.rds.amazonaws.com",
    port: port,
    user: "admin",
    password: process.env.newsDBPassword,
    database: "news",
});
con.connect(function (err) {
    if (err)
        throw err;
    console.log("Connected!");
});
exports.default = con;
//# sourceMappingURL=dbConnect.js.map