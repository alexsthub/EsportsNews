"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const chrome_aws_lambda_1 = __importDefault(require("chrome-aws-lambda"));
class OverwatchDetailsScraper {
    constructor(url, parser, currentData, headless = true) {
        this.url = url;
        this.parser = parser;
        this.currentData = currentData;
        this.headless = headless;
    }
    getUrl() {
        return this.url;
    }
    async scrape() {
        let result = null;
        let browser = null;
        try {
            browser = await chrome_aws_lambda_1.default.puppeteer.launch({
                args: ["--no-sandbox", "--disable-setuid-sandbox"],
                executablePath: await chrome_aws_lambda_1.default.executablePath,
                headless: this.headless,
                defaultViewport: chrome_aws_lambda_1.default.defaultViewport,
                ignoreHTTPSErrors: true,
            });
            const page = await browser.newPage();
            await page.goto(this.url, { waitUntil: "networkidle2" });
            result = await page.evaluate(this.parser);
            this.currentData.rawDatetime = result;
        }
        catch (error) {
            console.log(error);
        }
        finally {
            if (browser !== null) {
                await browser.close();
            }
        }
        return [this.currentData];
    }
}
exports.default = OverwatchDetailsScraper;
//# sourceMappingURL=OverwatchDetailsScraper.js.map