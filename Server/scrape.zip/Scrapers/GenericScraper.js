"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const chrome_aws_lambda_1 = __importDefault(require("chrome-aws-lambda"));
class GenericScraper {
    constructor(url, parser, headless = true) {
        this.url = url;
        this.parser = parser;
        this.headless = headless;
    }
    getUrl() {
        return this.url;
    }
    async scrape() {
        console.log("Entering scrape call");
        let browser = null;
        let result = null;
        try {
            console.log("Opening browser");
            browser = await chrome_aws_lambda_1.default.puppeteer.launch({
                args: chrome_aws_lambda_1.default.args,
                executablePath: await chrome_aws_lambda_1.default.executablePath,
                headless: chrome_aws_lambda_1.default.headless,
                defaultViewport: chrome_aws_lambda_1.default.defaultViewport,
                ignoreHTTPSErrors: true,
            });
            console.log("Launched");
            console.log(browser);
            const page = await browser.newPage();
            console.log("Created new page");
            await page.goto(this.url, { waitUntil: "networkidle2" });
            console.log("Arrived at new page");
            result = await page.evaluate(this.parser);
            console.log("Evaluated page! THIS IS GOOD NEWS");
        }
        catch (error) {
            console.log(error);
        }
        finally {
            console.log("Finally");
            console.log(browser);
            if (browser !== null) {
                console.log("Closing browser");
                await browser.close();
            }
        }
        return result;
    }
}
exports.default = GenericScraper;
//# sourceMappingURL=GenericScraper.js.map